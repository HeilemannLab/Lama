# -*- coding: utf-8 -*-

'''
    <mainwindow.py.>
    part of
    LocAlization Microscopy Analyzer (Lama)
    Copyright (C) <2015>  <Sebastian Malkusch>
    <malkusch@chemie.uni-frankfurt.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created: Fri Oct  3 17:41:50 2014
#      by: PyQt4 UI code generator 4.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import uic, QtGui
from PyQt4.QtCore import *
import lama_app as la
import lama_communicate as lc
import numpy as np

( Ui_MainWindow, QMainWindow ) = uic.loadUiType( 'mainwindow.ui' )
def define_file_type(self):
        files=[]
        if self.ui.radioButton_01.isChecked():
            files=[self.filename]
            self.file_type=0
        else:
            files=la.read_filenames(self.filename)
            self.file_type=1
        return files

def define_roi(self):
    '''
    defines the edges of the roi
    '''
    roi=np.zeros([4,2])
    roi[0,0]=float(self.ui.lineEdit_02.text())*1000
    roi[0,1]=float(self.ui.lineEdit_03.text())*1000
    roi[1,0]=float(self.ui.lineEdit_04.text())*1000
    roi[1,1]=float(self.ui.lineEdit_05.text())*1000
    roi[2,0]=float(self.ui.lineEdit_06.text())
    roi[2,1]=float(self.ui.lineEdit_07.text())
    roi[3,0]=float(self.ui.lineEdit_08.text())
    roi[3,1]=float(self.ui.lineEdit_09.text())
    return roi

def define_cbc_roi(self):
    '''
        defines the edges of the roi
        '''
    roi=np.zeros([4,2])
    roi[0,0]=float(self.ui.lineEdit_02.text())*1000
    roi[0,1]=float(self.ui.lineEdit_03.text())*1000
    roi[1,0]=float(self.ui.lineEdit_04.text())*1000
    roi[1,1]=float(self.ui.lineEdit_05.text())*1000
    roi[2,0]=float(self.ui.lineEdit_06.text())
    roi[2,1]=float(self.ui.lineEdit_07.text())
    roi[3,0]=float(self.ui.lineEdit_10.text())
    roi[3,1]=float(self.ui.lineEdit_11.text())
    return roi

    
class MainWindow ( QMainWindow ):
    """MainWindow inherits QMainWindow"""

    def __init__ ( self, parent = None ):
        QMainWindow.__init__( self, parent )
        self.toolbox = QtGui.QToolBox(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi( self )
        self.toolbox.resize(300,500)
        
    # Main Window actions
    # get filename
        self.ui.lineEdit_01.setDragEnabled(True)
        self.ui.lineEdit_01.setAcceptDrops(True)
        self.ui.pushButton_01.clicked.connect(self.browse_input_path)
        self.ui.lineEdit_01.textChanged.connect(self.drop_input_path)
    # create image and MCA 
        self.ui.pushButton_02.clicked.connect(self.visualize)
    # calculate Thompson accuracy
        self.ui.pushButton_03.clicked.connect(self.Thompson_acc)
    # calculate NeNA accuracy
        self.ui.pushButton_04.clicked.connect(self.NeNA_acc)
    # Ripley's K-function
        self.ui.pushButton_05.clicked.connect(self.ripley)
    # Register channels
        self.ui.pushButton_06.clicked.connect(self.register)
    # Calculate CBC
        self.ui.pushButton_07.clicked.connect(self.cbc_procedure)
    # Load Settings
        self.ui.lineEdit_36.setDragEnabled(True)
        self.ui.lineEdit_36.setAcceptDrops(True)
        self.ui.pushButton_08.clicked.connect(self.browse_import_path)
        self.ui.lineEdit_36.textChanged.connect(self.drop_import_path)
        self.ui.pushButton_09.clicked.connect(self.import_settings)
    # Save Settings
        self.ui.lineEdit_37.setDragEnabled(True)
        self.ui.lineEdit_37.setAcceptDrops(True)
        self.ui.pushButton_10.clicked.connect(self.browse_save_path)
        self.ui.lineEdit_37.textChanged.connect(self.drop_save_path)
        self.ui.pushButton_11.clicked.connect(self.save_settings) 
        
        

    def __del__ ( self ):
        self.ui = None

        
 # Main Window funcions       
    def browse_input_path(self):
        '''
            get path name from pyQT
            Update lineEdit
        '''
        self.filename = QtGui.QFileDialog.getOpenFileName(self, 'Open File', '.')
        self.ui.lineEdit_01.setText(self.filename)
    
    def drop_input_path(self):
        '''
            update lineEdit_01 for new filename
        '''
        self.filename=str(self.ui.lineEdit_01.text())
        self.ui.lineEdit_01.setText(self.filename)

    def visualize(self):
        pxl=int(self.ui.lineEdit_15.text())
        acc=int(self.ui.lineEdit_16.text())
        if self.ui.checkBox_01.isChecked():
            conv_ind=1
        else:
            conv_ind=0
        if self.ui.checkBox_02.isChecked():
            fixed_ind=1
        else:
            fixed_ind=0
        fix_val=int(self.ui.lineEdit_17.text())
        if self.ui.checkBox_03.isChecked():
            mca_ind=1
        else:
            mca_ind=0
        if self.ui.radioButton_03.isChecked():
            cbc_ind=0
            roi=define_roi(self)
        else:
            cbc_ind=1
            roi=define_cbc_roi(self)
        thr=float(self.ui.lineEdit_18.text())
        min_r=float(self.ui.lineEdit_19.text())
        max_r=float(self.ui.lineEdit_20.text())
        files=define_file_type(self)        
        append='_statMIA'
        for i in range (0,len(files)):
            lc.analyze_roi_int(roi,pxl,files[i],conv_ind,acc,fixed_ind,fix_val,cbc_ind,mca_ind,thr,min_r,max_r,append)
        lc.statement()

    def Thompson_acc(self):
        append='_statMIA'
        files=define_file_type(self)
        con_fac=float(self.ui.lineEdit_12.text())
        pxl_size=float(self.ui.lineEdit_21.text())
        noise=float(self.ui.lineEdit_23.text())
        sigma=float(self.ui.lineEdit_13.text())
        roi=define_roi(self)
        if self.ui.radioButton_01.isChecked():
            lc.calc_Thompson(files[0],roi,con_fac,pxl_size,noise,sigma,append)
        else:
            for i in range (0,len(files)):
                lc.calc_Thompson(files[i],roi,con_fac,pxl_size,noise,sigma,append)
        lc.statement()

    def NeNA_acc(self):
        append='_statMIA'
        files=define_file_type(self)
        roi=define_roi(self)
        if self.ui.radioButton_01.isChecked():
            lc.calc_NeNA(files[0],roi,append)
        else:
            for i in range (0,len(files)):
                lc.calc_NeNA(files[i],roi,append)
        lc.statement()
    
    def ripley(self):
        append='_statMIA'
        files=define_file_type(self)
        pxl=int(self.ui.lineEdit_15.text())
        if self.ui.checkBox_02.isChecked():
            fixed_ind=1
        else:
            fixed_ind=0
        fix_val=int(self.ui.lineEdit_17.text())
        edge=float(self.ui.lineEdit_24.text())*1000
        radius=float(self.ui.lineEdit_25.text())*1000
        inc_num=int(self.ui.lineEdit_26.text())
        if self.file_type==0:
            rois=roi=np.zeros([1,2])
            rois[0,0]=float(self.ui.lineEdit_02.text())*1000
            rois[0,1]=float(self.ui.lineEdit_04.text())*1000
            lc.calc_ripley(files[0],rois,edge,radius,inc_num,pxl,fixed_ind,fix_val,append)
        else:
            for i in range (0,len(files),2):
                rois=lc.calc_ripley_rois(files[i+1])
                lc.calc_ripley(files[i],rois,edge,radius,inc_num,pxl,fixed_ind,fix_val,append)
        lc.statement()
        
    def register(self):
        if self.ui.radioButton_01.isChecked():
            print ('the lama can only operate registrations with multiple localization files')
        else:
            append='_statMIA'
            files=define_file_type(self)
            pxl=int(self.ui.lineEdit_15.text())
            if self.ui.checkBox_02.isChecked():
                fixed_ind=1
            else:
                fixed_ind=0
            fix_val=int(self.ui.lineEdit_17.text())
            roi=define_roi(self)
            r_min=int(self.ui.lineEdit_28.text())
            r_max=int(self.ui.lineEdit_29.text())
            r=int(self.ui.lineEdit_30.text())
            n=float(self.ui.lineEdit_31.text())
            d=int(self.ui.lineEdit_32.text())
            if self.ui.radioButton_05.isChecked():
                reg_ind=1
            else:
                reg_ind=0
            lc.calc_registration(files,roi,pxl,fixed_ind,fix_val,r_min,r_max,r,n,d,reg_ind,append)
            lc.statement()
        
    def cbc_procedure(self):
        append='_statMIA'
        files=define_file_type(self)
        r_max=int(self.ui.lineEdit_33.text())
        inc_num=int(self.ui.lineEdit_34.text())
        wf=float(self.ui.lineEdit_35.text())
        roi=define_roi(self)
        if self.ui.radioButton_01.isChecked() and self.ui.radioButton_07.isChecked():
            print ('the lama can only operate cbc analysis with multiple localization files')
        
        elif self.ui.radioButton_01.isChecked():
            lc.cbc_cluster(files[0],roi,r_max,inc_num,wf,append)
        else:
            if self.ui.radioButton_07.isChecked():
                for i in range (0,len(files),2):
                    print ('the lama calculates colocalization maps via CBC')
                    lc.cbc_coloc(files[i],files[i+1],roi,r_max,inc_num,wf,append)
            else:
                for i in range (0,len(files)):
                    print ('the lama calculates cluster maps via CBC')
                    lc.cbc_cluster(files[i],roi,r_max,inc_num,wf,append)
        lc.statement()
    
    def browse_import_path(self):
        '''
            get path name from pyQT
            Update lineEdit
        '''
        self.import_filename = QtGui.QFileDialog.getOpenFileName(self, 'Open File', '.')
        self.ui.lineEdit_36.setText(self.import_filename)
    
    def drop_import_path(self):
        '''
            update lineEdit_36 for new filename
        '''
        self.import_filename=str(self.ui.lineEdit_36.text())
        self.ui.lineEdit_36.setText(self.import_filename)
    
    def import_settings(self):
        settings=lc.load_settings(self.import_filename)
        if settings[0,0]==1.0:
            self.ui.radioButton_01.setChecked(True)
        else:
            self.ui.radioButton_02.setChecked(True)
        self.ui.lineEdit_02.setText(str(settings[1,0]))
        self.ui.lineEdit_03.setText(str(settings[2,0]))
        self.ui.lineEdit_04.setText(str(settings[3,0]))
        self.ui.lineEdit_05.setText(str(settings[4,0]))
        self.ui.lineEdit_06.setText(str(settings[5,0]))
        self.ui.lineEdit_07.setText(str(settings[6,0]))
        self.ui.lineEdit_08.setText(str(settings[7,0]))
        self.ui.lineEdit_09.setText(str(settings[8,0]))
        self.ui.lineEdit_10.setText(str(settings[9,0]))
        self.ui.lineEdit_11.setText(str(settings[10,0]))
        self.ui.lineEdit_12.setText(str(settings[11,0]))
        self.ui.lineEdit_13.setText(str(settings[12,0]))
        self.ui.lineEdit_14.setText(str(settings[13,0]))
        self.ui.lineEdit_15.setText(str(settings[14,0]))
        self.ui.lineEdit_16.setText(str(settings[15,0]))
        self.ui.lineEdit_17.setText(str(settings[16,0]))
        print (settings[17,0])
        if settings[17,0]==1.0:
            self.ui.radioButton_03.setChecked(True)
        else:
            self.ui.radioButton_04.setChecked(True)
        if settings[18,0]==1.0:
            self.ui.checkBox_01.setChecked(True)
        else:
            self.ui.checkBox_01.setChecked(False)
        if settings[19,0]==1.0:
            self.ui.checkBox_02.setChecked(True)
        else:
            self.ui.checkBox_02.setChecked(False)
        if settings[20,0]==1.0:
            self.ui.checkBox_03.setChecked(True)
        else:
            self.ui.checkBox_03.setChecked(False)
        self.ui.lineEdit_18.setText(str(settings[21,0]))
        self.ui.lineEdit_19.setText(str(settings[22,0]))
        self.ui.lineEdit_20.setText(str(settings[23,0]))
        self.ui.lineEdit_21.setText(str(settings[24,0]))
        self.ui.lineEdit_22.setText(str(settings[25,0]))
        self.ui.lineEdit_23.setText(str(settings[26,0]))
        self.ui.lineEdit_24.setText(str(settings[27,0]))
        self.ui.lineEdit_25.setText(str(settings[28,0]))
        self.ui.lineEdit_26.setText(str(settings[29,0]))
        self.ui.lineEdit_28.setText(str(settings[30,0]))
        self.ui.lineEdit_29.setText(str(settings[31,0]))
        self.ui.lineEdit_30.setText(str(settings[32,0]))
        self.ui.lineEdit_31.setText(str(settings[33,0]))
        self.ui.lineEdit_32.setText(str(settings[34,0]))
        if settings[35,0]==1.0:
            self.ui.radioButton_05.setChecked(True)
        else:
            self.ui.radioButton_06.setChecked(True)
        self.ui.lineEdit_33.setText(str(settings[36,0]))
        self.ui.lineEdit_34.setText(str(settings[37,0]))
        self.ui.lineEdit_35.setText(str(settings[38,0]))
        if settings[39,0]==1.0:
            self.ui.radioButton_07.setChecked(True)
        else:
            self.ui.radioButton_08.setChecked(True)
        
    def browse_save_path(self):
        '''
            get path name from pyQT
            Update lineEdit
        '''
        self.save_filename = QtGui.QFileDialog.getExistingDirectory(self, 'Save Settings', '.')
        self.ui.lineEdit_37.setText(self.save_filename)
    
    def drop_save_path(self):
        '''
            update lineEdit_37 for new filename
        '''
        self.save_filename=str(self.ui.lineEdit_37.text())
        self.ui.lineEdit_37.setText(self.save_filename)
    
    def save_settings(self):
        dir_name=self.save_filename
        settings=np.zeros([40,1])
        if self.ui.radioButton_01.isChecked():
            settings[0]=1
        settings[1]=float(self.ui.lineEdit_02.text())
        settings[2]=float(self.ui.lineEdit_03.text())
        settings[3]=float(self.ui.lineEdit_04.text())
        settings[4]=float(self.ui.lineEdit_05.text())
        settings[5]=float(self.ui.lineEdit_06.text())
        settings[6]=float(self.ui.lineEdit_07.text())
        settings[7]=float(self.ui.lineEdit_08.text())
        settings[8]=float(self.ui.lineEdit_09.text())
        settings[9]=float(self.ui.lineEdit_10.text())
        settings[10]=float(self.ui.lineEdit_11.text())
        settings[11]=float(self.ui.lineEdit_12.text())
        settings[12]=float(self.ui.lineEdit_13.text())
        settings[13]=float(self.ui.lineEdit_14.text())
        settings[14]=float(self.ui.lineEdit_15.text())
        settings[15]=float(self.ui.lineEdit_16.text())
        settings[16]=float(self.ui.lineEdit_17.text())
        if self.ui.radioButton_03.isChecked():
            settings[17]=1
        if self.ui.checkBox_01.isChecked():
            settings[18]=1
        if self.ui.checkBox_02.isChecked():
            settings[19]=1
        if self.ui.checkBox_03.isChecked():
            settings[20]=1
        settings[21]=float(self.ui.lineEdit_18.text())
        settings[22]=float(self.ui.lineEdit_19.text())
        settings[23]=float(self.ui.lineEdit_20.text())
        settings[24]=float(self.ui.lineEdit_21.text())
        settings[25]=float(self.ui.lineEdit_22.text())
        settings[26]=float(self.ui.lineEdit_23.text())
        settings[27]=float(self.ui.lineEdit_24.text())
        settings[28]=float(self.ui.lineEdit_25.text())
        settings[29]=float(self.ui.lineEdit_26.text())
        settings[30]=float(self.ui.lineEdit_28.text())
        settings[31]=float(self.ui.lineEdit_29.text())
        settings[32]=float(self.ui.lineEdit_30.text())
        settings[33]=float(self.ui.lineEdit_31.text())
        settings[34]=float(self.ui.lineEdit_32.text())
        if self.ui.radioButton_05.isChecked():
            settings[35]=1
        settings[36]=float(self.ui.lineEdit_33.text())
        settings[37]=float(self.ui.lineEdit_34.text())
        settings[38]=float(self.ui.lineEdit_35.text())
        if self.ui.radioButton_07.isChecked():
            settings[39]=1
        la.write_settings(settings,dir_name)
        lc.statement()