'''
    <lama_app.py.>
    part of
    LocAlization Microscopy Analyzer (Lama)
    Copyright (C) <2015>  <Sebastian Malkusch>
    <malkusch@chemie.uni-frankfurt.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

#lama_app
import numpy as np
import scipy as sp
import pylab as pl
import os
import math
import sys
import matplotlib.pyplot as plt
from scipy import ndimage
from scipy import spatial
from scipy.stats import spearmanr
from scipy.optimize import curve_fit
from PIL import Image, ImageDraw

def update_progress(progress):
    barLength = 10 # Modify this to change the length of the progress bar
    block = int(round(barLength*progress))
    text = "\rthe lama is processing: [{0}] {1}%".format( "#"*block + "-"*(barLength-block), int(progress*100)+1)
    sys.stdout.write(text)
    sys.stdout.flush()

def read_filenames(name):
    f = open(name)
    files = f.readlines()
    f.close
    for i in range (0,len(files)):
        try:
            files[i]=files[i].rstrip('\n')
        except ValueError:
            break
    return files

def read_locs(name):
    name=name.rstrip('\n')
    print ("the lama is pronking through "+ name)
    locs = np.loadtxt(name,skiprows = 0,comments='#')
    return locs


def read_locs_rs(name):
    name=name.rstrip('\n')
    print ("the lama is pronking through "+ name)
    locs = np.loadtxt(name,skiprows = 0,comments='#',usecols = (0,1,2,3))
    return locs

def make_dir(name,append):
    foldername=name+append
    if os.path.isdir(foldername)==False:
        os.mkdir(foldername)
    return foldername


def create_roi(locs,roi,name):
    outfilename=name + '/locs_roi.txt'
    idx1=locs[:,0]>=roi[0,0]
    idx2=locs[:,0]<=roi[0,1]
    idy1=locs[:,1]>=roi[1,0]
    idy2=locs[:,1]<=roi[1,1]
    idt1=locs[:,2]>=roi[2,0]
    idt2=locs[:,2]<=roi[2,1]
    idint1=locs[:,3]>=roi[3,0]
    idint2=locs[:,3]<=roi[3,1]
    locs1 = (locs[(idx1&idx2&idy1&idy2&idt1&idt2&idint1&idint2),:])
    np.savetxt(outfilename, locs1, fmt='%.5e', delimiter='   ')
    return locs1
    
def create_roi_ripley(locs,roi,name):
    outfilename=name + '/roi_ripley.txt'
    idx1=locs[:,0]>=roi[0,0]
    idx2=locs[:,0]<=roi[0,1]
    idy1=locs[:,1]>=roi[1,0]
    idy2=locs[:,1]<=roi[1,1]
    locs1 = (locs[(idx1&idx2&idy1&idy2),:])
    np.savetxt(outfilename, locs1, fmt='%.5e', delimiter='   ')
    return locs1

def make_Image(locs,roi,pxl,fixed_ind,fix_val,name):
    outfilename=name + '/roi_int.png'
    locs=locs.astype(int)
    BW0=np.histogram2d(locs[:,0], locs[:,1],bins=[(roi[0,1]-roi[0,0])/pxl,(roi[1,1]-roi[1,0])/pxl], range=[[roi[0,0],roi[0,1]],[roi[1,0],roi[1,1]]])[0]
    BW0=np.rot90(BW0, k=1)
    BW0=np.flipud(BW0)
    BW1=BW0
    if fixed_ind==1:
        BW1=np.clip(BW1,0,fix_val)
        BW1=(np.divide(BW1,fix_val)*255)
    BW2 = Image.fromarray(np.uint8(BW1))
    BW2.save(outfilename)
    return (BW0)
    
def convolve_image(BW0,sigma,fixed_ind,fix_val,name):
    outfilename=name + '/roi_iwm.png'
    BW1 = ndimage.gaussian_filter(BW0, sigma)
    if fixed_ind==1:
        BW1=np.clip(BW1,0,fix_val)
        BW1=(np.divide(BW1,fix_val)*255)
    else:
        BW1=(np.divide(BW1,(np.max(BW1)))*255)
    BW2 = Image.fromarray(np.uint8(BW1))
    BW2.save(outfilename)
    return (BW1)
    

def bud_locs(BW,MinR,MaxR,r,pxl,name):
    Binaryename=name + '/First_channel_Bin.png'
    R=float(r/pxl)
    BW1 = ndimage.gaussian_filter(BW, 0.2)
    mask = BW1 > 0
    mask1=ndimage.morphology.binary_opening(mask,iterations=1)
    mask2=ndimage.morphology.binary_closing(mask1,iterations=1)
    
    label_im, nb_labels = ndimage.label(mask2)
    sizes = ndimage.sum(mask2, label_im, range(nb_labels + 1))
    mask_r=np.dot(np.sqrt(np.divide(sizes,np.pi)),pxl)
    mask_size = mask_r <= MinR
    remove_pixel = mask_size[label_im]
    label_im[remove_pixel] = 0

    label_im, nb_labels = ndimage.label(label_im)
    sizes = ndimage.sum(mask2, label_im, range(nb_labels + 1))
    mask_r=np.dot(np.sqrt(np.divide(sizes,np.pi)),pxl)
    mask_size = mask_r > MaxR
    remove_pixel = mask_size[label_im]
    label_im[remove_pixel] = 0

    BW0 = ndimage.binary_fill_holes(label_im)
    BW2 = Image.fromarray(np.uint8(BW0)*255)
    BW2.save(Binaryename)

    label_im, nb_labels = ndimage.label(label_im)
    coord  =(np.array(ndimage.center_of_mass(BW,label_im, range(nb_labels+1))))[1:,[1, 0]]
    tree=spatial.KDTree(coord)
    x=tree.query_ball_point(coord, (R))
    sort_coord=[]
    for i in range (0,len(x)):
        if len(x[i])==1:
            sort_coord.append(coord[i,:])
    sort_coord=np.array(sort_coord)
    return (np.dot(sort_coord,pxl))

def make_binary(BW, Thr):
     mask = BW > Thr
     return mask

def imb_ana(mask,BW0,roi, thr,min_r,max_r,pxl, dir_name):
    label_im, nb_labels = ndimage.label(mask)
    sizes = ndimage.sum(mask, label_im, range(nb_labels + 1))
    mask_r=np.dot(np.sqrt(np.divide(sizes,np.pi)),pxl)
    mask_size=mask_r<=min_r
    remove_pixel = mask_size[label_im]
    label_im[remove_pixel] = 0
    
    label_im, nb_labels = ndimage.label(label_im)
    sizes = ndimage.sum(mask, label_im, range(nb_labels + 1))
    mask_r=np.dot(np.sqrt(np.divide(sizes,np.pi)),pxl)
    mask_size=mask_r>=max_r
    remove_pixel = mask_size[label_im]
    label_im[remove_pixel] = 0
    
    binary = ndimage.binary_fill_holes(label_im)
    maskname=dir_name+'/mask'+'.png'
    BW1 = Image.fromarray(np.uint8(binary)*255)
    BW1.save(maskname)
    
    im_name=dir_name+'/masked_roi.png'
    BW2=Image.fromarray(np.uint8(np.multiply(BW0,binary)))
    BW2.save(im_name)
    
    label_im, nb_labels = ndimage.label(label_im)
    coord  = (np.array(ndimage.center_of_mass(BW0,label_im, range(nb_labels+1))))[1:,[1, 0]]
    sizes  = (ndimage.sum(mask, label_im, range(nb_labels + 1)))[1:]
    l=len(coord[:,0])
    mca_res  = np.zeros([l,5])
    mca_res[:,0]  = roi[0,0]+np.dot(coord[:, 0],pxl)
    mca_res[:,1]  = roi[1,0]+np.dot(coord[:, 1],pxl)
    mca_res[:,2]  = np.dot(sizes,(pxl**2))
    mca_res[:,3]  = np.dot(np.sqrt(np.divide(sizes,np.pi)),pxl)
    mca_res[:,4]  = ndimage.sum(BW0, label_im, range(nb_labels))
    outname=dir_name+'/mca_roi.txt'
    np.savetxt(outname, mca_res, fmt='%.5e', delimiter='   ')

def print_theo_acc(list,name):
    Min=0
    Max=int(np.max(list))
    Int=0.1
    Inc=(Max-Min)/Int
    x=np.arange(Min,Max,Int,dtype='float')
    y=np.histogram(list, bins=Inc, range=(Min,Max), density=True)[0]
    f, axarr = plt.subplots(1, sharex=False)
    axarr.bar(x, y, color='gray', edgecolor='black',width=Int)
    axarr.set_xlim([Min,Max])
    axarr.set_xlabel('loc_acc [nm]')
    axarr.set_ylabel('Intensity [a.u.]')
    plt.savefig(name, format='pdf')



def Thompson(locs,con_fac,pxl_size,noise,sigma,dir_name):
    length=np.shape(locs)[0]
    sa=(np.square(sigma)+np.square(pxl_size)/12)
    theo_acc=np.zeros([length,2])
    for i in range (0,length):
        theo_acc[i,0]=np.sqrt((sa/(locs[i,3]/con_fac))+((8*np.pi*np.square(sigma)*np.square(sigma)*np.square(noise)))/(np.square(pxl_size)*np.square(locs[i,3]/con_fac)))
        theo_acc[i,1]=np.sqrt((sa/(locs[i,3]/con_fac))*((16.0/9)+((8*np.pi*sa*np.square(noise))/((locs[i,3]/con_fac)*np.square(pxl_size)))))
        progress=float(i/length)
        update_progress(progress)
    print ('\n')
    outname=dir_name+'/theo_lac.txt'
    np.savetxt(outname, theo_acc, fmt='%.5e', delimiter='   ')
    thom_name=dir_name+'/thom_acc.pdf'
    print_theo_acc(theo_acc[:,0],thom_name)
    mort_name=dir_name+'/mort_acc.pdf'
    print_theo_acc(theo_acc[:,1],mort_name)

def min_dist(point,locs):
    d=np.sqrt(np.square(locs[:,0]-point[0])+np.square(locs[:,1]-point[1]))
    return np.min(d)

def NeNA(locs,dir_name):
    max_frame=np.max(locs[:,2])
    length=np.shape(locs)[0]
    frames=np.zeros([length,2])
    frames[:,1]=locs[:,2]
    tree=spatial.KDTree(frames[:,0:2])
    d=np.zeros([length,1])
    p=-1
    for i in range (0,length):
        o=locs[i,2]
        # j muss angeben,ob naechster Frame existent ist
        j=locs[i+1,2]-locs[i,2]
        if locs[i,2]<max_frame and o==p:
            d[i]=min_dist(locs[i,0:3],temp_locs)
            p=o
        elif locs[i,2]<max_frame and o>p:
            temp_locs=locs[tree.query_ball_point([0,o+1], 0.1),0:2]
            if np.shape(temp_locs)[0]>0:
                d[i]=min_dist(locs[i,0:3],temp_locs)
                p=o
            progress=float(locs[i,2]/(max_frame))
            update_progress(progress)
        elif locs[i,2]==max_frame:
            break
    print ('\n')
    idx=d>0
    NeNA_dist=d[idx]
    NeNA_acc, NeNA_err=plot_NeNA(NeNA_dist,dir_name)
    hd="the average lecalization accuracy by NeNA is at %.1f [nm]" %(float(NeNA_acc[0]))
    outname=dir_name+'/NeNA_lac.txt'
    np.savetxt(outname, NeNA_dist, fmt='%.5e', delimiter='   ',header=hd,comments='# ')

def CFunc2dCorr(r,a,rc,w,F,A,O):
    y=(r/(2*a*a))*np.exp((-1)*r*r/(4*a*a))*A+(F/(w*np.sqrt(np.pi/2)))*np.exp(-2*((r-rc)/w)*((r-rc)/w))+O*r
    return y

def Area(r,y):
    Areaf=abs(np.trapz(y, r))
    return Areaf

def CFit_resultsCorr(r,y):
    A=Area(r,y)
    p0 = np.array([10.0,15,100,(A/2),(A/2),((y[98]/200))])
    popt, pcov = curve_fit(CFunc2dCorr,r,y,p0)
    return popt, pcov

def plot_NeNA(NeNA_dist,dir_name):
    Min=0
    Max=150
    Int=1
    Inc=(Max-Min)/Int
    x=np.arange(Min,Max,Int,dtype='float')
    y=np.histogram(NeNA_dist, bins=Inc, range=(Min,Max), density=True)[0]
    acc, acc_err=CFit_resultsCorr(x,y)
    NeNA_func=CFunc2dCorr(x,acc[0],acc[1],acc[2],acc[3],acc[4],acc[5])
    name=dir_name+'/NeNA_lac.pdf'
    f, axarr = plt.subplots(1, sharex=False)
    axarr.bar(x, y, color='gray', edgecolor='black',width=Int)
    axarr.plot(x,NeNA_func, 'b')
    axarr.set_xlim([Min,Max])
    axarr.set_xlabel('loc_acc [nm]')
    axarr.set_ylabel('Intensity [a.u.]')
    plt.savefig(name, format='pdf')
    return acc, acc_err

'''
def tanslate_manual(locs,x,y,a,name):
    locs[:,0]=locs[:,0]+x
    locs[:,1]=locs[:,1]+y
    #hier noch rotation einfuehren
    outname=name +'/channel_translated.txt'
    np.savetxt(outname, locs, fmt='%.5e', delimiter='   ')
'''

def delete_beads(locs,buds,r,n):
    m=max(locs[:,2])-(n*(max(locs[:,2])/100.0))
    tree=spatial.KDTree(locs[:,0:2])
    x=tree.query_ball_point(buds, r)
    lengths = np.asarray([len(m) for m in x]).astype('float')
    idx = np.where((lengths < m) & (lengths > 1))
    sort_buds = buds[(idx), :][0]
    return sort_buds

def detect_beads(locs,buds,r,n):
    m=(n*((max(locs[:,2])-min(locs[:,2]))/100.0))
    #m=max(locs[:,2])-(n*(max(locs[:,2])/100.0))
    tree=spatial.KDTree(locs[:,0:2])
    x=tree.query_ball_point(buds, r)
    lengths = np.asarray([len(j) for j in x]).astype('float')
    idx = np.where(lengths > m)
    sort_buds = buds[(idx), :][0]
    return sort_buds

def write_sort_beads(buds01,buds02,name01,name02):
    bud_name01=name01[0:(len(name01)-4)]+'_Beads.txt'
    bud_name02=name02[0:(len(name02)-4)]+'_Beads.txt'
    np.savetxt(bud_name01, buds01, fmt='%.5e', delimiter='   ')
    np.savetxt(bud_name02, buds02, fmt='%.5e', delimiter='   ')

def write_sort_buds(buds01,name01):
    bud_name01=name01[0:(len(name01)-4)]+'_fasc.txt'
    np.savetxt(bud_name01, buds01, fmt='%.5e', delimiter='   ')

def draw_roi(BW,buds,r,pxl,name):
    Clustername=name +'/First_channel_Cluster.png'
    R=float(r/pxl)
    buds=np.divide(buds,pxl)
    Im = Image.fromarray(np.uint8(BW)*255)
    draw =ImageDraw.Draw(Im)
    for x,y in buds:
        draw.ellipse((x-R,y-R,x+R,y+R), outline=255)
        draw.point((x,y), fill=255)
    Im.save(Clustername)

def link_fuducials(buds01,buds02,rmax):
    tree01=spatial.KDTree(buds01[:,0:2])
    tree02=spatial.KDTree(buds02[:,0:2])
    x01=tree01.query_ball_point(buds02, rmax)
    x02=tree02.query_ball_point(buds01, rmax)
    idx01=[]
    idx02=[]
    for i in range(0,len(x01)):
        if len(x01[i])==1:
            idx01=np.append(idx01,i).astype('int')
    buds02=buds02[idx01,:]
    for i in range(0,len(x02)):
        if len(x02[i])==1:
            idx02=np.append(idx02,i).astype('int')
    buds01=buds01[idx02,:]
    tree01=spatial.KDTree(buds01[:,0:2])
    x01=tree01.query_ball_point(buds02, rmax)
    idx01=[]
    for i in range(0,len(x01)):
        if len(x01[i])==1:
            idx01=np.append(idx01,i).astype('int')
    buds02=buds02[idx01,:]
    return buds01,buds02

def plot_buds(buds01,buds02,name):
    outname=name+'/buds.pdf'
    plt.plot(buds01[:,0],buds01[:,1], 'ob')
    plt.plot(buds02[:,0],buds02[:,1], 'xr')
    plt.savefig(outname, bbox_inches='tight')
    plt.close()

def create_Affine_Matrix(fp,tp):
    BeadNumber=len(fp)
    M=np.zeros ([2*BeadNumber,6], float)
    M[0:BeadNumber,0]=fp[:,0]
    M[0:BeadNumber,1]=fp[:,1]
    M[0:BeadNumber,2]=1
    M[BeadNumber:2*BeadNumber,3]=fp[:,0]
    M[BeadNumber:2*BeadNumber,4]=fp[:,1]
    M[BeadNumber:2*BeadNumber,5]=1
    B=np.zeros([2*BeadNumber,1], float)
    for i in range (0,BeadNumber):
        B[i]= tp[i,0]
        B[i+BeadNumber]=tp[i,1]
    x = np.linalg.lstsq(M, B)[0]
    return x

def create_lin_trans_Matrix(fp,tp):
    BeadNumber=len(fp)
    M=np.zeros([2*BeadNumber,4], float)
    y=np.zeros([9,1], float)
    M[0:BeadNumber,0]=fp[:,0]
    M[0:BeadNumber,1]=1
    M[BeadNumber:2*BeadNumber,2]=fp[:,1]
    M[BeadNumber:2*BeadNumber,3]=1
    B=np.zeros([2*BeadNumber,1], float)
    for i in range (0,BeadNumber):
        B[i]= tp[i,0]
        B[i+BeadNumber]=tp[i,1]
    x = np.linalg.lstsq(M, B)[0]
    y[0]=x[0]
    y[2]=x[1]
    y[4]=x[2]
    y[5]=x[3]
    y[8]=1
    return y

def translate_locs(locs,H):
    # Form Affine Matrix from H
    M=np.zeros([3,3],float)
    M[0,0]=H[0]
    M[0,1]=H[1]
    M[0,2]=H[2]
    M[1,0]=H[3]
    M[1,1]=H[4]
    M[1,2]=H[5]
    M[2,2]=1
    # Translate
    p=np.zeros([3,1])
    p[2]=1
    for i in range (0,len(locs)):
        p[0]=locs[i,0]
        p[1]=locs[i,1]
        o=np.dot(M,p)
        locs[i,0]=o[0]
        locs[i,1]=o[1]
    return locs
    
def register_channels(locs02,buds02,buds01,name):
    H=create_Affine_Matrix(buds02,buds01)
    locs025=translate_locs(locs02,H)
    outname=name +'/channel_registered.txt'
    np.savetxt(outname, locs025, fmt='%.5e', delimiter='   ')
'''
def register_channels_trans(locs02,buds02,buds01,name):
    H=create_lin_trans_Matrix(buds02,buds01)
    locs025=translate_locs(locs02,H)
    outname=name +'/channel_registered.txt'
    np.savetxt(outname, locs025, fmt='%.5e', delimiter='   ')
'''

def register_channels_trans(locs02,buds02,buds01,name):
    H=buds02-buds01
    locs025=locs02
    locs025[:,0]=locs02[:,0]-np.mean(H[:,0])
    locs025[:,1]=locs02[:,1]-np.mean(H[:,1])
    outname=name +'/channel_registered.txt'
    np.savetxt(outname, locs025, fmt='%.5e', delimiter='   ')


def bud_dist(locs02,fids02,fids01,name):
    x=fids02[:,0]-fids01[:,0]
    y=fids02[:,1]-fids01[:,1]
    locs02[:,0]=locs02[:,0]+np.mean(x)
    locs02[:,1]=locs02[:,1]+np.mean(y)
    outname=name +'/channel_registered.txt'
    np.savetxt(outname, locs02, fmt='%.5e', delimiter='   ')

def RipleysEdge(BoxOR,Dist,name):
    Length=len(BoxOR)
    NMR=0
    BoxMR=np.zeros([(9*Length),2])
    BoxMR[0:Length,0]=BoxOR[:,0]
    BoxMR[0:Length,1]=BoxOR[:,1];
    
    NMR=NMR+Length
    BoxMR[NMR:(NMR+Length),0]=BoxOR[:,0]-Dist
    BoxMR[NMR:(NMR+Length),1]=BoxOR[:,1]+Dist
    
    NMR=NMR+Length
    BoxMR[NMR:(NMR+Length),0]=BoxOR[:,0]
    BoxMR[NMR:(NMR+Length),1]=BoxOR[:,1]+Dist;
    
    NMR=NMR+Length
    BoxMR[NMR:(NMR+Length),0]=BoxOR[:,0]+Dist
    BoxMR[NMR:(NMR+Length),1]=BoxOR[:,1]+Dist
    
    NMR=NMR+Length
    BoxMR[NMR:(NMR+Length),0]=BoxOR[:,0]-Dist
    BoxMR[NMR:(NMR+Length),1]=BoxOR[:,1]
    
    NMR=NMR+Length
    BoxMR[NMR:(NMR+Length),0]=BoxOR[:,0]+Dist
    BoxMR[NMR:(NMR+Length),1]=BoxOR[:,1]
    
    NMR=NMR+Length
    BoxMR[NMR:(NMR+Length),0]=BoxOR[:,0]-Dist
    BoxMR[NMR:(NMR+Length),1]=BoxOR[:,1]-Dist
    
    NMR=NMR+Length
    BoxMR[NMR:(NMR+Length),0]=BoxOR[:,0]
    BoxMR[NMR:(NMR+Length),1]=BoxOR[:,1]-Dist
    
    NMR=NMR+Length
    BoxMR[NMR:(NMR+Length),0]=BoxOR[:,0]+Dist
    BoxMR[NMR:(NMR+Length),1]=BoxOR[:,1]-Dist
    
    Boxname=name + '/TEC_locs.txt'
    np.savetxt(Boxname, BoxMR, fmt='%.3e', delimiter='   ')

    return BoxMR

def RipleysK(BoxOR,BoxMR,Ink,R,d,name):
    Distx=np.zeros([(len(BoxMR)),1])
    Disty=np.zeros([(len(BoxMR)),1])
    Dist=np.zeros([(len(BoxMR)),1])
    Kr=np.zeros([Ink,3])
    end_val=np.shape(BoxOR)[0]
    for i in range(0, (len(BoxOR))):
        Distx[:,0]=BoxOR[i,0]-BoxMR[:,0]
        Disty[:,0]=BoxOR[i,1]-BoxMR[:,1]
        Dist =(np.sqrt(np.power(Distx, 2)+np.power(Disty, 2)))
        Dist =np.delete(Dist, i, 0)
        for n in range(0,Ink):
            r=n*(R/Ink)
            Kr[n,0]=len(np.nonzero(Dist<r)[0])
        Kr[:,1]=Kr[:,1]+Kr[:,0]
        progress=float(i/end_val)
        update_progress(progress)
    print('\n')

    Ro=len(BoxOR)/(d**2)
    est=Ro*(math.pi*(R**2))*len(BoxOR)
    lam=1/(math.pi*(R**2))
    Kr[:,2]=Kr[:,1]/(lam*est)
    
    K=np.zeros([Ink,7])
    for n in range(0,Ink):
        r=n*(R/Ink)
        K[n,0]=r
        K[n,1]=np.pi*r*r
        K[n,2]=Kr[n,2]
        K[n,3]=r
        K[n,4]=np.sqrt(K[n,2]/np.pi)
        K[n,5]=K[n,3]-r
        K[n,6]=K[n,4]-r
    m=np.argmax(K[:,6])
    H="Ripley's K-Function Maximum %.1f at r = %.1f [nm]." %(K[m,6],K[m,0])
    RIPname=name + '/ripley.txt'
    np.savetxt(RIPname, K, fmt='%.3e', delimiter='   ', header=H, comments='# ')

    Plotname=name + '/ripley.pdf'
    plt.plot(K[:,0], K[:,5], 'b')
    plt.plot(K[:,0], K[:,6], 'r')
    plt.savefig(Plotname, bbox_inches='tight')
    plt.close()

def RipleysK_01(BoxOR,BoxMR,Ink,R,d,name):
    Kr=np.zeros([Ink,2])
    treeB=spatial.KDTree(BoxOR[:,0:2])
    treeA=spatial.KDTree(BoxMR[:,0:2])
    rp=R/Ink
    r=np.arange(0,R,rp)
    Kr[:,0]=treeA.count_neighbors(treeB, r)
    Ro=len(BoxOR)/(d**2)
    est=Ro*(math.pi*(R**2))*len(BoxOR)
    lam=1/(math.pi*(R**2))
    Kr[:,1]=Kr[:,0]/(lam*est)
    
    K=np.zeros([Ink,7])
    for n in range(0,Ink):
        r=n*(R/Ink)
        K[n,0]=r
        K[n,1]=np.pi*r*r
        K[n,2]=Kr[n,1]
        K[n,3]=r
        K[n,4]=np.sqrt(K[n,2]/np.pi)
        K[n,5]=K[n,3]-r
        K[n,6]=K[n,4]-r
    m=np.argmax(ripley[:,6])
    #hier maximum in Header einarbeiten
    H="Ripley's K-Function Maximum %.1f at r = %.1f [nm]." %(K[m,6],K[m,0])
    RIPname=name + '/ripley.txt'
    np.savetxt(RIPname, K, fmt='%.3e', delimiter='   ',header=H, comments='# ')
    
    Plotname=name + '/ripley.pdf'
    plt.plot(K[:,0], K[:,5], 'b')
    plt.plot(K[:,0], K[:,6], 'r')
    plt.savefig(Plotname, bbox_inches='tight')
    plt.close()

#Fuer K-Function verwenden????
def partner_test(locsA,locsB,inc,rmax):
    treeB=spatial.KDTree(locsB[:,0:2])
    treeA=spatial.KDTree(locsA[:,0:2])
    rp=rmax/inc
    r=np.arange(0,rmax,rp)
    X=treeA.count_neighbors(treeB, r[1])
    print (X)

def ripley_max(ripley):
    m=np.argmax(ripley[:,6])
    return (ripley[m,0], ripley[m,6])

def write_ripley_max(max,name):
    out_name=name +'/ripley_max.txt'
    np.savetxt(out_name, max, fmt='%.3e', delimiter='   ')

def print_ripley_box(files,n,name):
    if n==0:
        out_name=name +'/ripley_box_radius.pdf'
    elif n==1:
        out_name=name +'/ripley_box_max.pdf'
    plt.figure()
    for i in range (0,len(files)):
        x=read_locs(files[i])
        #ripley=
        plt.boxplot(ripley[:,n],0,'')
        plt.hold()
    plt.savefig(out_name, bbox_inches='tight')
    plt.close()

def create_cbc_roi(locs,roi,dir_name,name):
    outfilename=dir_name + name
    idx1=locs[:,0]>=roi[0,0]
    idx2=locs[:,0]<=roi[0,1]
    idy1=locs[:,1]>=roi[1,0]
    idy2=locs[:,1]<=roi[1,1]
    idt1=locs[:,2]>=roi[2,0]
    idt2=locs[:,2]<=roi[2,1]
    locs1 = (locs[(idx1&idx2&idy1&idy2&idt1&idt2),:])
    np.savetxt(outfilename, locs1, fmt='%.5e', delimiter='   ')
    return locs1

def cbc(locsA,locsB,rmax,inc,w):
    area=np.zeros([inc,1])
    dist=np.zeros([inc,3])
    C=np.zeros([len(locsA),1])
    rp=rmax/inc
    for i in range(0,inc):
        r1=rp*i
        r2=rp*(i+1)
        area[i]=math.pi*((r2**2)-(r1**2))
    treeB=spatial.KDTree(locsB[:,0:2])
    treeA=spatial.KDTree(locsA[:,0:2])
    end_val=np.shape(locsA)[0]
    for i in range (0,end_val):
        loc=locsA[i,0:2]
        #Verteilung B
        roi=[]
        roi_idx_B=treeB.query_ball_point(loc,rmax)
        roi=locsB[roi_idx_B,:]
        distB=np.sqrt(((roi[:,0]-loc[0])**2)+((roi[:,1]-loc[1])**2))
        histB=np.histogram(distB, bins=inc, range=(0,rmax))
        dist[:,0]=histB[1][1:]
        dist[:,1]=np.divide(histB[0],area.T)
        n=len(roi)
        #Verteilung A
        roi=[]
        roi_idx_A=treeA.query_ball_point(loc,rmax)
        roi=locsA[roi_idx_A,:]
        distA=np.sqrt(((roi[:,0]-loc[0])**2)+((roi[:,1]-loc[1])**2))
        histA=np.histogram(distA, bins=inc, range=(0,rmax))
        dist[:,2]=np.divide(histA[0],area.T)
        m=len(roi)
        # Correlation und Wichtung
        if n>5 and m>5:
            S=spearmanr(dist[:,1], dist[:,2])[0]
            D=min(distB)
            C[i]=S*np.e**(-w*D/rmax)
        else:
            C[i]=0
        progress=float(i/end_val)
        update_progress(progress)
    print('\n')
    return C


def split_cbc_locs(locs):
    ind=locs[:,2]%2==0
    locs_A=locs[ind,:]
    ind=locs[:,2]%2!=0
    locs_B=locs[ind,:]
    return (locs_A,locs_B)

def combine_split_cbc_locs(locs_A,locs_B):
    locs=np.append(locs_A,locs_B,axis=0)
    locs=locs[locs[:,2].argsort(axis=0)]
    return locs

def make_CBC_image(locs,roi,pxl,dir_name):
    outfilename_cbc=dir_name+'/cbc_ind.png'
    outfilename_int=dir_name+'/cbc_locs.png'
    Z=(locs[:,3]+1)/2
    BW0=np.histogram2d(locs[:,0], locs[:,1],bins=[(roi[0,1]-roi[0,0])/pxl,(roi[1,1]-roi[1,0])/pxl], range=[[roi[0,0],roi[0,1]],[roi[1,0],roi[1,1]]])[0]
    BW0=np.rot90(BW0, k=1)
    BW0=np.flipud(BW0)
    BW0=np.clip(BW0,0,255)
    BW1=np.clip(BW0, 1, 255)
    BW2=np.histogram2d(locs[:,0], locs[:,1],bins=[(roi[0,1]-roi[0,0])/pxl,(roi[1,1]-roi[1,0])/pxl], range=[[roi[0,0],roi[0,1]],[roi[1,0],roi[1,1]]],weights=Z)[0]
    BW2=np.rot90(BW2, k=1)
    BW2=np.flipud(BW2)
    BW3=np.dot(np.divide(BW2, BW1),255)
    BW4 = Image.fromarray(np.uint8(BW3))
    BW4.save(outfilename_cbc)
    BW5 = Image.fromarray(np.uint8(BW0))
    BW5.save(outfilename_int)
    return BW0

def write_offset(roi,pxl,dir_name):
    o=[roi[0,0],roi[1,0],pxl]
    hd="image offset: xmin [nm], ymin[nm], pxl[nm]"
    outname=dir_name+'/offset.txt'
    np.savetxt(outname, o, fmt='%.5e', delimiter='   ',header=hd,comments='# ')

def roi_from_file(raw):
    roi=np.zeros([5,2])
    for i in range (0,5):
        roi_line=np.array(raw[(5+i)].split())
        roi[i,:]=roi_line.astype(np.float, copy=False)
    return roi

def rest_from_file(raw):
    rest=np.zeros([29,1])
    j=0
    for i in range (0,3):
        rest_line=np.array(raw[(11+j)].split())
        j+=1
        rest[i]=rest_line.astype(np.float, copy=False)
    j=0
    for i in range (3,6):
        rest_line=np.array(raw[(16+j)].split())
        j+=1
        rest[i]=rest_line.astype(np.float, copy=False)
    j=0
    for i in range (6,9):
        rest_line=np.array(raw[(20+j)].split())
        j+=1
        rest[i]=rest_line.astype(np.float, copy=False)
    rest_line=np.array(raw[(25)].split())
    rest[9]=rest_line.astype(np.float, copy=False)
    j=0
    for i in range (10,13):
        rest_line=np.array(raw[(27+j)].split())
        j+=1
        rest[i]=rest_line.astype(np.float, copy=False)
    j=0
    for i in range (13,16):
        rest_line=np.array(raw[(31+j)].split())
        j+=1
        rest[i]=rest_line.astype(np.float, copy=False)
    j=0
    for i in range (16,19):
        rest_line=np.array(raw[(35+j)].split())
        j+=1
        rest[i]=rest_line.astype(np.float, copy=False)
    j=0
    for i in range (19,24):
        rest_line=np.array(raw[(39+j)].split())
        j+=1
        rest[i]=rest_line.astype(np.float, copy=False)
    rest_line=np.array(raw[(45)].split())
    rest[24]=rest_line.astype(np.float, copy=False)
    j=0
    for i in range (25,28):
        rest_line=np.array(raw[(47+j)].split())
        j+=1
        rest[i]=rest_line.astype(np.float, copy=False)
    rest_line=np.array(raw[(51)].split())
    rest[28]=rest_line.astype(np.float, copy=False)
    return rest
    
def read_import_file(name):
    file = open(name)
    raw=file.read().splitlines()
    file.close
    type=int(raw[3])
    roi=roi_from_file(raw)
    rest=rest_from_file(raw)
    return type,roi,rest

    
def write_settings(settings,dir_name):
    out_name=dir_name+'/settings.txt'
    out_file = open(out_name, "w")
    out_file.write('# Settings file:\n')
    out_file.write('# Main\n')
    out_file.write('# file name type:\n')
    out_file.write('%i\n' %(settings[0]))
    out_file.write('# roi:\n')
    out_file.write('%.3f\t%.3f\n' %(settings[1], settings[2]))
    out_file.write('%.3f\t%.3f\n' %(settings[3], settings[4]))
    out_file.write('%.3f\t%.3f\n' %(settings[5], settings[6]))
    out_file.write('%.3f\t%.3f\n' %(settings[7], settings[8]))
    out_file.write('%.3f\t%.3f\n' %(settings[9], settings[10]))
    out_file.write('# setup:\n')
    out_file.write('%.3f\n' %(settings[11]))
    out_file.write('%.3f\n' %(settings[12]))
    out_file.write('%.3f\n' %(settings[13]))
    out_file.write('# Visualize\n')
    out_file.write('# image:\n')
    out_file.write('%.3f\n' %(settings[14]))
    out_file.write('%.3f\n' %(settings[15]))
    out_file.write('%.3f\n' %(settings[16]))
    out_file.write('# image type:\n')
    out_file.write('%i\n' %(settings[17]))
    out_file.write('%i\n' %(settings[18]))
    out_file.write('%i\n' %(settings[19]))
    out_file.write('# mca:\n')
    out_file.write('# enable mca:\n')
    out_file.write('%i\n' %(settings[20]))
    out_file.write('# mca specs:\n')
    out_file.write('%.3f\n' %(settings[21]))
    out_file.write('%.3f\n' %(settings[22]))
    out_file.write('%.3f\n' %(settings[23]))
    out_file.write('# Accuracy:\n')
    out_file.write('%.3f\n' %(settings[24]))
    out_file.write('%.3f\n' %(settings[25]))
    out_file.write('%.3f\n' %(settings[26]))
    out_file.write('# Ripley:\n')
    out_file.write('%.3f\n' %(settings[27]))
    out_file.write('%.3f\n' %(settings[28]))
    out_file.write('%.3f\n' %(settings[29]))
    out_file.write('# Register:\n')
    out_file.write('%.3f\n' %(settings[30]))
    out_file.write('%.3f\n' %(settings[31]))
    out_file.write('%.3f\n' %(settings[32]))
    out_file.write('%.3f\n' %(settings[33]))
    out_file.write('%.3f\n' %(settings[34]))
    out_file.write('# Registeration type:\n')
    out_file.write('%i\n' %(settings[35]))
    out_file.write('# CBC:\n')
    out_file.write('%.3f\n' %(settings[36]))
    out_file.write('%.3f\n' %(settings[37]))
    out_file.write('%.3f\n' %(settings[38]))
    out_file.write('# CBC type:\n')
    out_file.write('%i\n' %(settings[39]))
    out_file.write('# go Lama!')
    out_file.close()
